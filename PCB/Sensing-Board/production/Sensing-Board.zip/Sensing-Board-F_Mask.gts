G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.2-5-g56e69c1c8f*
G04 #@! TF.CreationDate,2026-06-24T23:32:45+02:00*
G04 #@! TF.ProjectId,Sensing-Board,53656e73-696e-4672-9d42-6f6172642e6b,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.2-5-g56e69c1c8f) date 2026-06-24 23:32:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.200000X-0.200000X-0.275000X0.200000X-0.275000X0.200000X0.275000X-0.200000X0.275000X0*%
%ADD11R,1.000000X0.400000*%
%ADD12R,1.300000X2.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,TH405*
X124350000Y-53000000D03*
X126000000Y-53000000D03*
G04 #@! TD*
G04 #@! TO.C,TH404*
X158100000Y-53000000D03*
X159750000Y-53000000D03*
G04 #@! TD*
G04 #@! TO.C,TH403*
X158100000Y-147000000D03*
X159750000Y-147000000D03*
G04 #@! TD*
G04 #@! TO.C,TH402*
X124350000Y-147000000D03*
X126000000Y-147000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J403*
X99700000Y-54250000D03*
X99700000Y-55250000D03*
X99700000Y-56250000D03*
X99700000Y-57250000D03*
X99700000Y-58250000D03*
X99700000Y-59250000D03*
X99700000Y-60250000D03*
X99700000Y-61250000D03*
D12*
X97000000Y-51450000D03*
X97000000Y-64050000D03*
G04 #@! TD*
M02*
